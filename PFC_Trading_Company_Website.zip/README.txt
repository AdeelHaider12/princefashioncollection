PFC Trading Company website
- Open index.html in a browser to preview.
- Upload index.html to your hosting provider / website root.
- The website uses online Google Fonts and Unsplash images, so an internet connection is required for those assets.
- WhatsApp buttons are linked to +91 90811 08517.
- Contact email used: pcollection68@gmail.com (from the supplied profile content).
